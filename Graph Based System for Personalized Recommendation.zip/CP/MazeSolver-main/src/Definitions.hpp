#define myWidth 1600
#define myHeight 900

#define FONT_PATH "fonts//Tajawal-Medium.ttf"
#define BACKGROUND_PATH "imgs//background.jpg"
#define LEFT_ARROW_IMAGE_PATH "imgs//leftArrow.png"
#define RIGHT_ARROW_IMAGE_PATH "imgs//rightArrow.png"
#define ICON_PATH "imgs//icon.png"
